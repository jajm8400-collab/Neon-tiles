// Corre Beat This! en segundo plano (sin trabar el juego).
// Entrada: {pcm: Float32Array mono 22050 Hz}. Salida: {beats, downbeats, meter} en segundos.
importScripts('../ort/ort.wasm.min.js','mel.js','beat.js');
let session=null;
async function getSession(){
  if(session)return session;
  ort.env.wasm.wasmPaths=new URL('../ort/',self.location.href).href;
  ort.env.wasm.numThreads=1;
  const r=await fetch(new URL('../models/beat_this.onnx',self.location.href));
  if(!r.ok)throw new Error('modelo no disponible');
  const buf=await r.arrayBuffer();
  session=await ort.InferenceSession.create(buf,{executionProviders:['wasm'],graphOptimizationLevel:'all'});
  return session}
self.onmessage=async e=>{
  const {id,pcm}=e.data;
  try{
    const s=await getSession();
    self.postMessage({id,type:'progress',p:.03});
    const mel=await logMel(pcm,async p=>{self.postMessage({id,type:'progress',p:.03+p*.07})});
    const r=await runBeatThis(ort,s,mel.data,mel.frames,async p=>{self.postMessage({id,type:'progress',p:.1+p*.88})});
    const raw=peaksMinimal(r.beat).map(f=>f/FPS),rawDown=peaksMinimal(r.down).map(f=>f/FPS);
    const tr=trackBeats(r.beat,r.down);
    self.postMessage({id,type:'done',beats:tr.beats,raw,rawDown,meter:tr.meter,downIdx:tr.downIdx,period:tr.period})}
  catch(err){self.postMessage({id,type:'error',msg:String(err&&err.message||err)})}};

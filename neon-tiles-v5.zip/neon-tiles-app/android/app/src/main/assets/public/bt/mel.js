// Espectrograma log-mel idéntico al de Beat This (torchaudio MelSpectrogram):
// sr 22050, n_fft 1024, hop 441 (50 fps), hann periódica, center+reflect,
// normalized="frame_length", power=1, mel slaney sin normalización, 128 bandas 30–11000 Hz,
// salida log1p(1000*mel). Devuelve Float32Array [frames*128].
function hzToMelSlaney(f){const fsp=200/3,minLogHz=1000,minLogMel=minLogHz/fsp,logstep=Math.log(6.4)/27;return f>=minLogHz?minLogMel+Math.log(f/minLogHz)/logstep:f/fsp}
function melToHzSlaney(m){const fsp=200/3,minLogHz=1000,minLogMel=minLogHz/fsp,logstep=Math.log(6.4)/27;return m>=minLogMel?minLogHz*Math.exp(logstep*(m-minLogMel)):fsp*m}
function melFilterbank(sr,nfft,nmels,fmin,fmax){
  const nb=nfft/2+1,fb=[],mmin=hzToMelSlaney(fmin),mmax=hzToMelSlaney(fmax),pts=[];
  for(let i=0;i<nmels+2;i++)pts.push(melToHzSlaney(mmin+(mmax-mmin)*i/(nmels+1)));
  const freqs=[];for(let k=0;k<nb;k++)freqs.push(k*sr/nfft);
  for(let m=0;m<nmels;m++){const lo=pts[m],ce=pts[m+1],hi=pts[m+2],row=new Float32Array(nb);let a=nb,b=-1;
    for(let k=0;k<nb;k++){const f=freqs[k],w=Math.max(0,Math.min((f-lo)/(ce-lo),(hi-f)/(hi-ce)));if(w>0){row[k]=w;if(k<a)a=k;b=k}}
    fb.push({row,a,b})}
  return fb}
function makeFFT(N){const lv=Math.log2(N),rev=new Uint32Array(N);for(let i=0;i<N;i++){let r=0,x=i;for(let b=0;b<lv;b++){r=(r<<1)|(x&1);x>>=1}rev[i]=r}
  const co=new Float64Array(N/2),si=new Float64Array(N/2);for(let i=0;i<N/2;i++){co[i]=Math.cos(2*Math.PI*i/N);si[i]=-Math.sin(2*Math.PI*i/N)}
  return(re,im)=>{for(let i=0;i<N;i++){const j=rev[i];if(j>i){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t}}
    for(let sz=2;sz<=N;sz<<=1){const h=sz>>1,st=N/sz;for(let i=0;i<N;i+=sz)for(let j=0,k=0;j<h;j++,k+=st){const a=i+j,b=a+h,tr=re[b]*co[k]-im[b]*si[k],ti=re[b]*si[k]+im[b]*co[k];re[b]=re[a]-tr;im[b]=im[a]-ti;re[a]+=tr;im[a]+=ti}}}}
async function logMel(x,onProg){
  const N=1024,HOP=441,NM=128,pad=N/2,len=x.length,nf=1+Math.floor(len/HOP);
  const win=new Float64Array(N);let wsum=0;for(let i=0;i<N;i++){win[i]=.5-.5*Math.cos(2*Math.PI*i/N);wsum+=win[i]*win[i]}
  const norm=1/Math.sqrt(wsum),fb=melFilterbank(22050,N,NM,30,11000),fft=makeFFT(N);
  const re=new Float64Array(N),im=new Float64Array(N),mag=new Float64Array(N/2+1),out=new Float32Array(nf*NM);
  const at=i=>{if(i<0)i=-i;if(i>=len)i=2*(len-1)-i;return x[i]||0};
  for(let f=0;f<nf;f++){const s=f*HOP-pad;
    if(s>=0&&s+N<=len){for(let i=0;i<N;i++){re[i]=x[s+i]*win[i];im[i]=0}}else{for(let i=0;i<N;i++){re[i]=at(s+i)*win[i];im[i]=0}}
    fft(re,im);for(let k=0;k<=N/2;k++)mag[k]=Math.sqrt(re[k]*re[k]+im[k]*im[k])*norm;
    const o=f*NM;for(let m=0;m<NM;m++){const {row,a,b}=fb[m];let s2=0;for(let k=a;k<=b;k++)s2+=row[k]*mag[k];out[o+m]=Math.log1p(1000*s2)}
    if(onProg&&f%1000===0)await onProg(f/nf)}
  return{data:out,frames:nf}}
if(typeof module!=='undefined')module.exports={logMel,melFilterbank};

// Inferencia de Beat This! por trozos (igual que File2Beats: 1500 frames, borde 6, keep_first)
// + postproceso mejorado: programación dinámica sobre la activación (continuidad de beat estable)
// y compás consistente a partir de la activación de downbeat.
const FPS=50;
async function runBeatThis(ort,session,mel,frames,onProg){
  const CH=1500,BD=6,NM=128,beat=new Float32Array(frames),down=new Float32Array(frames);
  let starts=[];for(let s=-BD;s<frames-BD;s+=CH-2*BD)starts.push(s);
  if(frames>CH-2*BD)starts[starts.length-1]=frames-(CH-BD);
  const inName=session.inputNames[0],outs=session.outputNames;
  const oBeat=outs.find(n=>/beat/i.test(n)&&!/down/i.test(n))||outs[0],oDown=outs.find(n=>/down/i.test(n))||outs[1];
  // keep_first: se escribe en orden inverso para que el primer trozo gane
  const preds=[];
  for(let ci=0;ci<starts.length;ci++){const st=starts[ci],a=Math.max(st,0),b=Math.min(st+CH,frames);
    const padL=Math.max(0,-st),padR=Math.max(0,Math.min(BD,st+CH-frames)),T=padL+(b-a)+padR,buf=new Float32Array(T*NM);
    buf.set(mel.subarray(a*NM,b*NM),padL*NM);
    const r=await session.run({[inName]:new ort.Tensor('float32',buf,[1,T,NM])});
    preds.push({st,T,b:r[oBeat].data,d:r[oDown].data});if(onProg)await onProg((ci+1)/starts.length)}
  for(let ci=preds.length-1;ci>=0;ci--){const p=preds[ci];for(let i=BD;i<p.T-BD;i++){const f=p.st+i;if(f>=0&&f<frames){beat[f]=p.b[i];down[f]=p.d[i]}}}
  return{beat,down}}
const sig=x=>1/(1+Math.exp(-x));
function peaksMinimal(logits){const out=[];const n=logits.length;let run=null;
  for(let i=0;i<n;i++){let mx=-1e9;for(let k=Math.max(0,i-3);k<=Math.min(n-1,i+3);k++)mx=Math.max(mx,logits[k]);
    if(logits[i]===mx&&logits[i]>0){if(run&&i-run.last<=1){run.c++;run.p+=(i-run.p)/run.c;run.last=i}else{if(run)out.push(run.p);run={p:i,c:1,last:i}}}}
  if(run)out.push(run.p);return out}
// Beat tracking por programación dinámica (Ellis) sobre la probabilidad de beat de la red.
function dpBeats(act,frames){
  // tempo: autocorrelación de la activación
  const lagMin=Math.round(FPS*60/220),lagMax=Math.round(FPS*60/50),ac=new Float32Array(lagMax*2+2);
  for(let L=lagMin;L<=lagMax*2+1&&L<frames;L++){let s=0;for(let i=0;i+L<frames;i++)s+=act[i]*act[i+L];ac[L]=s/(frames-L)}
  let best=lagMin,bv=-1;for(let L=lagMin;L<=lagMax;L++){const v=ac[L]+.5*(ac[2*L]||0);if(v>bv){bv=v;best=L}}
  let P=best;{const a=ac[best-1]||0,b=ac[best],c=ac[best+1]||0,den=a-2*b+c;if(den<0)P=best+.5*(a-c)/den}
  const sc=new Float32Array(frames),bk=new Int32Array(frames).fill(-1),TI=6;
  for(let t=0;t<frames;t++){let v0=-1e9,bi=-1;const lo=Math.max(0,Math.round(t-1.6*P)),hi=Math.round(t-P*.6);
    for(let p=lo;p<=hi;p++){const v=sc[p]-TI*Math.pow(Math.log((t-p)/P),2);if(v>v0){v0=v;bi=p}}
    sc[t]=act[t]+(bi>=0?Math.max(0,v0):0);bk[t]=v0>0?bi:-1}
  let end=frames-1,mx=-1;for(let t=Math.max(0,frames-Math.round(P));t<frames;t++)if(sc[t]>mx){mx=sc[t];end=t}
  const bf=[];for(let t=end;t>=0;t=bk[t])bf.push(t);bf.reverse();
  // refina cada beat al máximo local de la activación (±2 frames) con interpolación parabólica
  return{beats:bf.map(f=>{let m=f;for(let k=-2;k<=2;k++)if(act[f+k]>act[m])m=f+k;const a=act[m-1]||0,b=act[m],c=act[m+1]||0,den=a-2*b+c;return den<0?m+.5*(a-c)/den:m}),period:P}}
// Combina: picos de la red cuando son confiables + huecos rellenados por DP.
function trackBeats(beatLogits,downLogits){
  const n=beatLogits.length,act=new Float32Array(n);for(let i=0;i<n;i++)act[i]=sig(beatLogits[i]);
  const net=peaksMinimal(beatLogits),dp=dpBeats(act,n),P=dp.period;
  // fusión: partir de la red; donde falten beats (hueco > 1.5 periodos) insertar los del DP
  const out=[];let j=0;const dps=dp.beats;
  for(let i=0;i<net.length;i++){const cur=net[i];out.push(cur);const nx=net[i+1];
    if(nx!==undefined&&nx-cur>1.5*P){while(j<dps.length&&dps[j]<=cur+.5*P)j++;while(j<dps.length&&dps[j]<nx-.5*P){out.push(dps[j]);j++}}}
  if(!net.length)out.push(...dps);
  // antes del primer y después del último beat de la red
  const first=out[0],last=out[out.length-1];
  const pre=dps.filter(b=>b<first-.5*P),post=dps.filter(b=>b>last+.5*P);
  const beats=[...pre,...out,...post].sort((a,b)=>a-b);
  // compás: probar métrica 3 o 4 y la fase que maximiza la activación de downbeat
  let bestM=4,bestPh=0,bestS=-1e9;
  for(const M of[3,4])for(let ph=0;ph<M;ph++){let s=0,c=0;for(let k=ph;k<beats.length;k+=M){const f=Math.round(beats[k]);s+=sig(downLogits[Math.min(n-1,Math.max(0,f))]);c++}const v=s/Math.max(1,c)-(M===3?.04:0);if(v>bestS){bestS=v;bestM=M;bestPh=ph}}
  return{beats:beats.map(f=>f/FPS),meter:bestM,downIdx:bestPh,period:P/FPS,netCount:net.length,dpCount:dps.length}}
if(typeof module!=='undefined')module.exports={runBeatThis,trackBeats,peaksMinimal,FPS};

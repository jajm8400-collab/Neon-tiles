# Neon Tiles ∞ — proyecto Android (APK)

Juego tipo Piano Tiles para Android. Las canciones (.mp3, .wav) se analizan dentro del teléfono, sin internet,
y quedan guardadas en la app. El juego está en `www/index.html`.

## Opción A — Compilar en GitHub (sin instalar nada)

1. Crea una cuenta gratis en github.com y un repositorio nuevo (privado si quieres).
2. En el repositorio: **Add file → Upload files**. Arrastra todo el contenido de esta carpeta
   (no la carpeta en sí) y pulsa **Commit changes**.
3. **Add file → Create new file**. Nombre: `.github/workflows/build.yml`.
   Pega el contenido de `build.yml.txt` y pulsa **Commit changes**.
   (Si la carpeta `.github` sí se subió en el paso 2, sáltate este paso.)
4. Ve a la pestaña **Actions**. Espera a que "Compilar APK" termine en verde (unos 5–8 min).
5. Abre esa ejecución, baja hasta **Artifacts** y descarga **NeonTiles-APK** (es un .zip con `app-debug.apk`).
6. Pasa el `.apk` a tu teléfono, ábrelo y acepta "Instalar apps de origen desconocido" cuando lo pida.

## Opción B — Compilar en tu PC con Android Studio

Requisitos: Node.js 22+, Android Studio (reciente) con JDK 21.

```
npm install
npx cap sync android
npx cap open android
```

En Android Studio: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
El archivo queda en `android/app/build/outputs/apk/debug/app-debug.apk`.
O conecta tu teléfono por USB (con depuración USB activada) y pulsa ▶ Run.

## Si cambias el juego

Edita `www/index.html` y vuelve a correr `npx cap sync android` (en GitHub basta con subir el archivo:
la compilación se hace sola).

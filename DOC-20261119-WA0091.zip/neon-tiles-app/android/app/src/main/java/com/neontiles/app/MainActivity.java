package com.neontiles.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
